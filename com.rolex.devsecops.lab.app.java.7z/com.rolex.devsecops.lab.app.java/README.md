# DevSecOps Lab on modern software development

## Overview

This project illustrates TDD & Clean Architecture implementation in Java, showing the Use Case Driven Development
Approach from Alexandre Cuva. It was used to create a base application to show good TDD & BDD practices

We implement a Hello World system with the following use cases:

- Create a name

The following feature still need to be implemented
- view hello world
- view a list of name

## Prerequisites

- OpenJDK 17

This application intend showing to the reader the best practices in Moderne Software development. It integrate practices
like:
* Domain Driven Design
* CQRS
* Clean Architecture
* Test Driven Development with Double Iteration through BDD and TDD
* Integration Test

The application was developed with:
* Spring Boot
* net.sizovs.pipelinr : MediaR paternes
* de.huxhorn.sulky.ulid : UUID Generators
* Testing framework:
  * Junit 5 : unit test
  * AssertJ : Fluentes assertions
  * Cucumber : Gherkins interpretation

## OKTA (Security framework)
Before starting to use Okta, you need to create a developer account under : https://dev-26475184-admin.okta.com/admin/getting-started

The Development documentation can be found under :
* https://github.com/okta/okta-spring-boot/ : Okta with Spring-boot
* Token : 00IjG9s9y-Q9n5-_u6abaXfEQ64L3NEdcsxDc_rW7F

Running build with automated tests:

```
./mvn test
```
Running JaCoCo code coverage:

```
./mvn jacoco:prepare-agent jacoco:report
```

Running PIT mutation testing:

```
./mvn pitest:mutationCoverage
```

Running App Map coverage :

It will automatically create during the test phase, to read the file check
on https://appland.com/docs/appmap-overview.html,

## Reports

See the `target` directory for the generated reports for test results, code coverage and mutation testing.

Reports:

- target/surefire-reports
- target/site/jacoco
- target/pit-reports
- target/appmap

## Swagger API
You can find Swagger API UI under `http://localhost:8080/swagger-ui/index.html`