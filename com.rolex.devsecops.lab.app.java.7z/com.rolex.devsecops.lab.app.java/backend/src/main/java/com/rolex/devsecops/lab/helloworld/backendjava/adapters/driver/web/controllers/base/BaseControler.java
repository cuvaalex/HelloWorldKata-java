package com.rolex.devsecops.lab.helloworld.backendjava.adapters.driver.web.controllers.base;

import an.awesome.pipelinr.Pipeline;
import org.springframework.beans.factory.annotation.Autowired;

public class BaseControler {
    @Autowired
    protected Pipeline pipeline;
}
