package com.rolex.devsecops.lab.helloworld.backendjava.core.ports.driven;

public interface HelloWorldIdGenerator {
    Long next();
}
