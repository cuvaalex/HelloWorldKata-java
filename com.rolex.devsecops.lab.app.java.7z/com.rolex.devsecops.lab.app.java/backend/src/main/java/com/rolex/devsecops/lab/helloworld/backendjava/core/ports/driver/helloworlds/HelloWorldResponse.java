package com.rolex.devsecops.lab.helloworld.backendjava.core.ports.driver.helloworlds;

public record HelloWorldResponse(long helloWorldId) {

}
