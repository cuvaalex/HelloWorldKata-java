package com.rolex.devsecops.lab.helloworld.backendjava.core.ports.driver.viewlisthelloworld;

import com.rolex.devsecops.lab.helloworld.backendjava.core.ports.driver.viewhelloworld.ViewHelloWorldResponse;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public record ViewListHelloWorldResponse(List<ViewHelloWorldResponse> listHelloWorld) {
    public ViewListHelloWorldResponse(List<ViewHelloWorldResponse> listHelloWorld) {
        this.listHelloWorld = Objects.requireNonNullElseGet(listHelloWorld, ArrayList::new);
    }
}
