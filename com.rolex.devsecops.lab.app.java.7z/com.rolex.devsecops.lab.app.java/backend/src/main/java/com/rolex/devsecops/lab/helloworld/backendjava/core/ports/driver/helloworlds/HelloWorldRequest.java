package com.rolex.devsecops.lab.helloworld.backendjava.core.ports.driver.helloworlds;

import an.awesome.pipelinr.Command;

public record HelloWorldRequest(String name) implements Command<HelloWorldResponse> {
}
