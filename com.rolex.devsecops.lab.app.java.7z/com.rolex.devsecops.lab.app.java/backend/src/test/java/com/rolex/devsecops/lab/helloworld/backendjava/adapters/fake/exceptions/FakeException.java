package com.rolex.devsecops.lab.helloworld.backendjava.adapters.fake.exceptions;

public class FakeException extends RuntimeException {
    public FakeException(String message) {
        super(message);
    }
}
