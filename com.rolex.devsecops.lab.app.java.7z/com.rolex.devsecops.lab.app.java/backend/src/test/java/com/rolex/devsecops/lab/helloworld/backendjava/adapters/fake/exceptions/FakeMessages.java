package com.rolex.devsecops.lab.helloworld.backendjava.adapters.fake.exceptions;

public interface FakeMessages {
    String GENERATOR_DOES_NOT_HAVE_NEXT = "Generator does not have next element";
}
