﻿using System.Net;
using FluentAssertions;
using Rolex.DevSecOps.Lab.HelloWorld.Consumer.Infrastructure.Client;
using Xunit;

namespace Rolex.DevSecOps.Lab.HelloWorld.Consumer.Test.Infrastructure.System;

public class HelloWorldClientSystemTest
{
    [Fact(Skip = "TODO")]
    public void Should_Return_An_HelloWorldId_When_Create_a_valid_helloworld_name()
    {
        HelloWorldApiClient client 
            = new HelloWorldApiClient(new Uri("http://localhost:7251"));

        var response = client.Create("Alex");
        
        response.Result.Should().NotBeNull();
        response.Result.HelloWorldId.Should().NotBeNull().And.BePositive();

    }
}