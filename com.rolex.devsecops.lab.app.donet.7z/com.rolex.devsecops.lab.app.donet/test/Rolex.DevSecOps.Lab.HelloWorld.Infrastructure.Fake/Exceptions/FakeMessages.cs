﻿namespace Rolex.DevSecOps.Lab.HelloWorld.Infrastructure.Fake.Exceptions;

public static class FakeMessages
{
    public const string GeneratorDoesNotHaveNext = "Generator does not have next element";
}