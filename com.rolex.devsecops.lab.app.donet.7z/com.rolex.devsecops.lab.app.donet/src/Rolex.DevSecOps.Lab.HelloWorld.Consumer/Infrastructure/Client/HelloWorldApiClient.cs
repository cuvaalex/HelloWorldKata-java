﻿using System.Net;
using System.Net.Http.Json;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace Rolex.DevSecOps.Lab.HelloWorld.Consumer.Infrastructure.Client;

public class HelloWorldApiClient
{
    private readonly Uri _baseUri;
    private HttpClient _client;

    public HelloWorldApiClient(Uri baseUri)
    {
        _baseUri = baseUri;
        _client = new HttpClient { BaseAddress = _baseUri };
    }

    public async Task<HelloWorldResponse?> Create(string name)
    {
        var request = new HelloWorldRequest(name);
        
        try
        {
            var response = await _client.PostAsJsonAsync(requestUri: "/hello-worlds", request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadFromJsonAsync<HelloWorldResponse>();
                return content;
            }

        }
        catch (Exception ex)
        {
            throw new HttpRequestException(
                string.Format("The HelloWorld API request for {0} {1} failed.",
                    "POST",
                    "/hello-worlds"), ex);
        }

        return null;
    }

    
    public record HelloWorldRequest(string name){}
    public record HelloWorldResponse(long? HelloWorldId){}
}