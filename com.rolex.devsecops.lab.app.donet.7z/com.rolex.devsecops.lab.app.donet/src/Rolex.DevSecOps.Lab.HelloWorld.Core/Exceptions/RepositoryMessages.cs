﻿namespace Rolex.DevSecOps.Lab.HelloWorld.Core.Exceptions;

public class RepositoryMessages
{
    public const string RepositoryCannotUpdateNonExistent = "Repository cannot update non existent";
}