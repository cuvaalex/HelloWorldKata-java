﻿namespace Rolex.DevSecOps.Lab.HelloWorld.Core.Exceptions;

public static class ValidationMessages
{
    public const string NameEmpty = "Name is empty";
    public const string HelloWorldIdUnder0 = "HelloWorldId is smaller or equals to 0";
}