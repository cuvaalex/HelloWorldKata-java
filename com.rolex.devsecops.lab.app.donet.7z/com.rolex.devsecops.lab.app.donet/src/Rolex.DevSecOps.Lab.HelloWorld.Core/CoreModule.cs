﻿namespace Rolex.DevSecOps.Lab.HelloWorld.Core;

public class CoreModule
{
    
}