﻿namespace Rolex.DevSecOps.Lab.HelloWorld.Core.UseCases.ViewHelloWorldName;

public record ViewHelloWorldNameResponse();